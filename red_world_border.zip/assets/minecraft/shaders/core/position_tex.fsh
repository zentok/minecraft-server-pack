#version 150

uniform sampler2D Sampler0;
uniform vec4 ColorModulator;

in vec2 texCoord0;

out vec4 fragColor;

void main() {
    vec4 tint = ColorModulator;

    // World border colours used by the game: stationary (blue), growing (green).
    // Both are replaced with the red used for a shrinking border.
    bool stationary = abs(tint.r - 0.1255) < 0.02 && abs(tint.g - 0.6275) < 0.02 && tint.b > 0.98;
    bool growing    = abs(tint.r - 0.2510) < 0.02 && tint.g > 0.98 && abs(tint.b - 0.5020) < 0.02;
    if (stationary || growing) {
        tint.rgb = vec3(1.0, 0.19, 0.19);
    }

    vec4 color = texture(Sampler0, texCoord0) * tint;
    if (color.a < 0.1) {
        discard;
    }
    fragColor = color;
}
